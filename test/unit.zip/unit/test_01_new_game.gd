extends GutTest

var MainMenuScene = load("res://scenes/main_menu/main_menu.tscn")
var current_scene_instance

func before_each():
	get_tree().paused = false
	GlobalGameManager.reset_data_mikro_saja()
	GlobalGameManager.reset_data_makro_saja()

func after_each():
	# Hapus instance scene secara paksa dari memori
	if is_instance_valid(current_scene_instance):
		current_scene_instance.free() # Menggunakan free() langsung agar instan hilang tanpa antrean queue
		current_scene_instance = null
		
	await wait_seconds(0.5)
	get_tree().paused = false

# ==============================================================================
# TEST CASE 1: New Game (Sampai Mengisi Nama & Konfirmasi)
# ==============================================================================
func test_01_visual_new_game_lengkap():
	gut.p("=== SKENARIO 1: NEW GAME LENGKAP ===")
	
	current_scene_instance = MainMenuScene.instantiate()
	add_child_autofree(current_scene_instance)
	await wait_seconds(0.8)
	
	gut.p("STEP 1: Mengklik 'NewGame_Button'...")
	var new_game_btn = current_scene_instance.get_node_or_null("NewGame_Button")
	if new_game_btn:
		new_game_btn.emit_signal("pressed")
	await wait_seconds(0.8)
	
	gut.p("STEP 2: Mengisi 'NameLineEdit' dengan 'Ksatria_Tegal'...")
	var name_line_edit = current_scene_instance.get_node_or_null("UI_Layer/NameInputPanel/NameLineEdit")
	if name_line_edit:
		name_line_edit.text = "Ksatria_Tegal"
		name_line_edit.emit_signal("text_changed", "Ksatria_Tegal")
	await wait_seconds(0.8)
	
	gut.p("STEP 3: Mengisi nama di memori global...")
	GlobalGameManager.player_name = "Ksatria_Tegal"
	
	# Validasi sebelum sistem sempat memuat loading screen prolog yang panjang
	assert_eq(GlobalGameManager.player_name, "Ksatria_Tegal", "Nama player berhasil disimpan!")
	assert_eq(GlobalGameManager.current_wave, 1, "Sesi baru dimulai dari Wave 1")
	
	gut.p("STEP 4: Membersihkan Scene MainMenu sebelum lanjut...")
	await wait_seconds(0.5)
