extends GutTest

var SettingsScene = load("res://scenes/main_menu/main_menu.tscn")
var current_scene_instance

func before_each():
	# 1. Pastikan game tidak terhenti (unpause)
	get_tree().paused = false
	
	# 2. Reset data memori global ke default awal
	GlobalGameManager.reset_data_mikro_saja()
	GlobalGameManager.reset_data_makro_saja()

func after_each():
	# 1. Paksa hapus instance scene utama dari memori secara langsung
	if is_instance_valid(current_scene_instance):
		current_scene_instance.free()
		current_scene_instance = null
		
	# 2. Sapu bersih seluruh node sisa yang menggantung di root layar pengujian
	for child in get_tree().root.get_children():
		# Pastikan tidak menghapus node internal bawaan GUT dan Engine
		if child != self and not child.name.begins_with("Gut") and not child.name.begins_with("@"):
			child.queue_free()
	
	# 3. Kembalikan kondisi pause & beri jeda 0.3 detik agar Godot selesai bersih-bersih
	get_tree().paused = false
	await wait_seconds(0.3)

# ==============================================================================
# TEST CASE 3: Settings Menu & Remap Key (Selesai -> Restart Murni)
# ==============================================================================
func test_03_settings_and_remap():
	gut.p("=== SKENARIO 3: SETTING MENU & REMAP TOMBOL ===")
	
	# STEP 1: Instansiasi Scene Settings Menu
	gut.p("STEP 1: Memuat UI Settings / Main Menu ke layar...")
	current_scene_instance = SettingsScene.instantiate()
	add_child_autofree(current_scene_instance)
	await wait_seconds(0.5)
	
	# STEP 2: Menekan tombol Controls
	gut.p("STEP 2: Mengklik tombol pengaturan Controls...")
	var controls_btn = current_scene_instance.find_child("ControlsButton", true, false)
	if controls_btn:
		controls_btn.emit_signal("pressed")
	await wait_seconds(0.3)
	
	# STEP 3: Simulasi remap tombol 'buka_tas' dari 'B' ke 'I'
	gut.p("STEP 3: Melakukan remap aksi 'buka_tas' ke tombol 'I'...")
	var action_name = "buka_tas"
	var event_baru = InputEventKey.new()
	event_baru.keycode = KEY_I
	
	if InputMap.has_action(action_name):
		InputMap.action_erase_events(action_name)
		InputMap.action_add_event(action_name, event_baru)
		
	var list_event = InputMap.action_get_events(action_name)
	assert_gt(list_event.size(), 0, "Aksi tombol berhasil diremap di InputMap!")
	
	# STEP 4: Menutup panel kontrol
	gut.p("STEP 4: Menutup panel kontrol settings...")
	var close_control_btn = current_scene_instance.find_child("CloseButton", true, false)
	if close_control_btn:
		close_control_btn.emit_signal("pressed")
	await wait_seconds(0.3)
	
	# STEP 5: Menutup keseluruhan Settings Menu
	gut.p("STEP 5: Menutup keseluruhan Settings Menu...")
	var main_close_btn = current_scene_instance.find_child("MainCloseButton", true, false)
	if main_close_btn:
		main_close_btn.emit_signal("pressed")
	await wait_seconds(0.3)
	
	assert_true(true, "Pengujian Settings, Remap Tas, dan Close Panel sukses dijalankan!")
	gut.p("--- PENGUJIAN TEST 3 SELESAI & LAYAR DIBERSIHKAN TOTAL ---")
