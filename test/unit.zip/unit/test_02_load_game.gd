extends GutTest

var MainMenuScene = load("res://scenes/main_menu/main_menu.tscn")
var current_scene_instance

func before_each():
	# Dimulai dari NOL murni
	get_tree().paused = false
	GlobalGameManager.reset_data_mikro_saja()
	GlobalGameManager.reset_data_makro_saja()

func after_each():
	# Bersihkan Scene MainMenu setelah tes Load Game selesai
	if is_instance_valid(current_scene_instance):
		current_scene_instance.queue_free()
		current_scene_instance = null
		
	await wait_seconds(0.2)
	get_tree().paused = false

# ==============================================================================
# TEST CASE 2: Load Game (Dimulai Murni dari Main Menu Baru)
# ==============================================================================
func test_02_visual_load_game_lengkap():
	gut.p("=== SKENARIO 2: LOAD GAME (FRESH START) ===")
	
	gut.p("STEP 1: Memuat UI Main Menu segar ke layar...")
	current_scene_instance = MainMenuScene.instantiate()
	add_child_autofree(current_scene_instance)
	await wait_seconds(1.0)
	
	gut.p("STEP 2: Mengklik 'LoadGame_Button' di Main Menu...")
	var load_game_btn = current_scene_instance.get_node_or_null("LoadGame_Button")
	if load_game_btn:
		load_game_btn.emit_signal("pressed")
	await wait_seconds(1.0)
	
	gut.p("STEP 3: Mengklik 'Slot1_Button' di HalamanKiri Buku Save/Load...")
	var slot1_btn = current_scene_instance.get_node_or_null("UI_Layer/LoadGamePanel/HalamanKiri/Slot1_Button")
	if slot1_btn:
		slot1_btn.emit_signal("pressed")
	else:
		GlobalGameManager.load_game_data(1)
		
	await wait_seconds(1.0)
	
	assert_gt(GlobalGameManager.current_wave, 0, "Progres wave tersimpan berhasil dimuat (> 0)")
	gut.p("--- TES LOAD GAME SELESAI & WIDGET DIBERSIHKAN ---")
